package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bugtable")
public class User {
   
	@Id
    private int bugid;
    private String bugname;
    private int bugline;
    private String projectname;
    private String timelimit;
    private String buglevel;
    private String bugpriority;
	
	public User() {}

	public User( int bugid, String bugname, int bugline, String projectname, String timelimit, String buglevel,
			String bugpriority) {
		super();
		
		this.bugid = bugid;
		this.bugname = bugname;
		this.bugline = bugline;
		this.projectname = projectname;
		this.timelimit = timelimit;
		this.buglevel = buglevel;
		this.bugpriority = bugpriority;
	}

	

	public int getBugId() {
		return bugid;
	}

	public void setBugId(int bugid) {
		this.bugid = bugid;
	}

	public String getBugName() {
		return bugname;
	}

	public void setBugName(String bugname) {
		this.bugname = bugname;
	}

	public int getBugLine() {
		return bugline;
	}

	public void setBugLine(int bugline) {
		this.bugline = bugline;
	}

	public String getProjectName() {
		return projectname;
	}

	public void setProjectName(String projectname) {
		this.projectname = projectname;
	}

	public String getTimeLimit() {
		return timelimit;
	}

	public void setTimeLimit(String timelimit) {
		this.timelimit = timelimit;
	}

	public String getBugLevel() {
		return buglevel;
	}

	public void setBugLevel(String buglevel) {
		this.buglevel = buglevel;
	}

	public String getBugPriority() {
		return bugpriority;
	}

	public void setBugPriority(String bugpriority) {
		this.bugpriority = bugpriority;
	}
	
	
	
	
	
}
