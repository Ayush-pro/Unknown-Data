package com.example.demo.Controller;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.model.User;
import com.example.demo.service.UserService;

@org.springframework.web.bind.annotation.RestController
public class RestController {

	@Autowired
	private UserService service;
	
	@PostMapping("/save-user")
	@Transactional
	@CrossOrigin
	public String registerUser(@RequestBody User user) {
		service.saveUser(user);
		return "Hello " +user.getBugId()+" for "+user.getProjectName()+ " is registered";
	}
	@GetMapping("/all-user")
	@CrossOrigin
	public Iterable<User> showAllUsers(){
		return service.showAllUsers();
	}
	@GetMapping("/delete/{bugid}")
	@Transactional
	@CrossOrigin
	public Iterable<User> deleteUser(@PathVariable int bugid){
		return service.deleteByBugid(bugid);
	}
	
	@GetMapping("/search/{bugid}")
	@CrossOrigin
	public User searchUser(@PathVariable int bugid) {
		return service.findByBugid(bugid);
	}

}
